/*
 * Note: To get instruction addresses, DO NOT compile this file yourself.
 * Instead, you should disassemble the existing rtarget binary.
 */

/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_314(unsigned x)
{
    return x + 2496104776U;
}

unsigned getval_257()
{
    return 2445773128U;
}

unsigned addval_435(unsigned x)
{
    return x + 3281016977U;
}

unsigned addval_298(unsigned x)
{
    return x + 3281293400U;
}

unsigned getval_395()
{
    return 3284633928U;
}

void setval_456(unsigned *p)
{
    *p = 3284633928U;
}

void setval_385(unsigned *p)
{
    *p = 2421198974U;
}

void setval_471(unsigned *p)
{
    *p = 1479568066U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_341(unsigned *p)
{
    *p = 3767077071U;
}

unsigned addval_144(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_427()
{
    return 3378563721U;
}

unsigned getval_305()
{
    return 3221801609U;
}

unsigned addval_346(unsigned x)
{
    return x + 3015956107U;
}

unsigned getval_327()
{
    return 3381969289U;
}

unsigned addval_374(unsigned x)
{
    return x + 3525364360U;
}

unsigned getval_323()
{
    return 3224947353U;
}

void setval_322(unsigned *p)
{
    *p = 2464188744U;
}

void setval_355(unsigned *p)
{
    *p = 3286272328U;
}

void setval_440(unsigned *p)
{
    *p = 3269495112U;
}

void setval_228(unsigned *p)
{
    *p = 3286272840U;
}

void setval_124(unsigned *p)
{
    *p = 3281046153U;
}

unsigned addval_386(unsigned x)
{
    return x + 2160318089U;
}

unsigned addval_320(unsigned x)
{
    return x + 3374372491U;
}

unsigned getval_368()
{
    return 3383020169U;
}

unsigned getval_134()
{
    return 3536109961U;
}

unsigned addval_254(unsigned x)
{
    return x + 3682915977U;
}

unsigned addval_176(unsigned x)
{
    return x + 2497087809U;
}

void setval_442(unsigned *p)
{
    *p = 3758704733U;
}

unsigned getval_474()
{
    return 3529558665U;
}

void setval_284(unsigned *p)
{
    *p = 3534015113U;
}

void setval_459(unsigned *p)
{
    *p = 3281043849U;
}

void setval_230(unsigned *p)
{
    *p = 3676362379U;
}

void setval_455(unsigned *p)
{
    *p = 3286272264U;
}

unsigned addval_464(unsigned x)
{
    return x + 3380134281U;
}

unsigned getval_317()
{
    return 3375939993U;
}

unsigned addval_226(unsigned x)
{
    return x + 3703816585U;
}

void setval_162(unsigned *p)
{
    *p = 3247494793U;
}

void setval_280(unsigned *p)
{
    *p = 3682124169U;
}

void setval_140(unsigned *p)
{
    *p = 3532964233U;
}

void setval_242(unsigned *p)
{
    *p = 3224426121U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
